"# ExpressTest"
___

# Install yarn!
```sh
$ npm install -g yarn
```

# Install packages!!
```sh
$ yarn install
```

# Run the app!!!
```sh
$ yarn start
```

# Go to:
```sh
$ http://localhost:3000/
```
